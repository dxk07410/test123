import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basicflow',
  templateUrl: './basicflow.component.html',
  styleUrls: ['./basicflow.component.scss']
})
export class BasicflowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
