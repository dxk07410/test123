import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  gridfiles: GridFiles[];
  cols: any[];

  data: any;
  bardata: any;

  constructor() {
    this.data = {
      labels: ['Unassigned','Exceptions','Review Complete', 'In Progress'],
      datasets: [
          {
              data: [340, 50, 100, 150],
              backgroundColor: [
                  "#ffad01",
                  "#f64649",
                  "#0069b3",
                  "#366090"
              ],
              hoverBackgroundColor: [
                "#ffad01",
                "#f64649",
                "#0069b3",
                "#366090"
              ]
          }]    
      };

      this.bardata = {
        labels: ['Mid-Market', 'Large-Market', 'Mega-Market'],
        datasets: [
            {
                label: 'My First dataset',
                backgroundColor: '#42A5F5',
                borderColor: '#1E88E5',
                data: [65, 59, 80]
            },
            {
                label: 'My Second dataset',
                backgroundColor: '#9CCC65',
                borderColor: '#7CB342',
                bardata: [28, 48, 40]
            }
        ]
    }
  }

  ngOnInit(): void {
    this.gridfiles = [
      {id: '100178', sponsors: 'Coco Cola', name: 'PP12345', effective: '05-21-2020', action: 'In Progress'},
      {id: '100178', sponsors: 'Coco Cola', name: 'PP12345', effective: '05-21-2020', action: 'In Progress'},
      {id: '100178', sponsors: 'Coco Cola', name: 'PP12345', effective: '05-21-2020', action: 'In Progress'},
      {id: '100178', sponsors: 'Coco Cola', name: 'PP12345', effective: '05-21-2020', action: 'In Progress'},
      {id: '100178', sponsors: 'Coco Cola', name: 'PP12345', effective: '05-21-2020', action: 'In Progress'}
    ];
    this.cols = [
      {field: 'id', header: 'Plan ID'},
      {field: 'sponsors', header: 'Plan Sponsors'},
      {field: 'name', header: 'Plan Name'},
      {field: 'effective', header: 'Effective Date'},
      {field: 'action', header: ''},
    ];
  }

}
export interface GridFiles {
  id;
  sponsors;
  name;
  effective;
  action;
}
